import { type GridScheduler } from './gridScheduler.js';
import { applyRenderWindowRuntimeLimits, computeRenderWindowInto, sameRenderedWindow, type RenderWindow } from './renderWindow.js';
import type { GridEngine } from '../engine/GridEngine.js';
import { GridMetric } from '../diagnostics/GridInstrumentation.js';
import type { GridLayoutPlan } from './layoutPlan.js';
import type { OverlayRenderer } from './overlayRenderer.js';
import type { PortalMountManager } from './portalMountManager.js';
import type { FrameCoordinator } from './frameCoordinator.js';
import type { RenderRuntimeStats } from './renderTelemetry.js';
import type { RowRenderer } from './rowRenderer.js';
import type { ScrollRenderContext } from './scrollRenderContext.js';
import type { HeaderRenderer } from './headerRenderer.js';
import type { FloatingFilterRenderer } from './floatingFilterRenderer.js';
import type { StickyGroupRenderer } from './stickyGroupRenderer.js';
import type { ViewportRenderer } from './viewportRenderer.js';
import type { LayoutTransitionController } from './layoutTransitionController.js';
import { compileStyleRules } from '../styling/styleRules.js';
import type { RenderRuntimeState } from './renderRuntimeState.js';

export interface RenderScrollCoordinatorState<TRowData = unknown> {
	viewportDirtyAfterScroll: boolean;
	flushPendingAfterScroll: boolean;
	needsPostScrollPortalFlush: boolean;
	portalFlushScheduled: boolean;
	postScrollDecorationScheduled: boolean;
	postScrollDecorationTimer: number | null;
	cachedMaxScrollLeft: number;
	cachedTotalWidth: number;
	cachedTotalHeight: number;
	cachedDefaultRowHeight: number;
	cachedHasSelectionOverlay: boolean;
	scrollCtx: ScrollRenderContext<TRowData>;
	renderWindowBufs: [RenderWindow, RenderWindow];
	activeRenderWindowBufIdx: number;
	portalFlushBudget: number;
	postScrollDecorationBudget: number;
}

export interface RenderScrollCoordinatorDeps<TRowData = unknown> {
	engine: GridEngine<TRowData>;
	viewportRenderer: ViewportRenderer<TRowData>;
	rowRenderer: RowRenderer<TRowData>;
	headerRenderer: HeaderRenderer<TRowData>;
	floatingFilterRenderer: FloatingFilterRenderer<TRowData>;
	overlayRenderer: OverlayRenderer<TRowData>;
	stickyGroupRenderer: StickyGroupRenderer<TRowData>;
	portalMountManager: PortalMountManager<TRowData>;
	frameCoordinator: FrameCoordinator;
	gridScheduler: GridScheduler;
	requestScrollFrame: () => void;
	layoutTransition: LayoutTransitionController<TRowData>;
	renderStats: RenderRuntimeStats;
	runtimeState: RenderRuntimeState;
	recycleViewport: (isScrollFrameActive: boolean, ctx?: ScrollRenderContext<TRowData>, precomputedWindow?: RenderWindow) => void;
	syncLayoutPlan: (renderWindow?: RenderWindow) => GridLayoutPlan;
}

export class RenderScrollCoordinator<TRowData = unknown> {
	constructor(
		private readonly deps: RenderScrollCoordinatorDeps<TRowData>,
		private readonly state: RenderScrollCoordinatorState<TRowData>
	) {}

	public getIsScrolling(): boolean {
		return this.deps.runtimeState.isScrolling();
	}

	public getIsScrollFrameActive(): boolean {
		return this.deps.runtimeState.phase === 'scroll-frame';
	}

	public markFlushPendingAfterScroll(): void {
		this.state.flushPendingAfterScroll = true;
	}

	public markViewportDirtyAfterScroll(): void {
		this.state.viewportDirtyAfterScroll = true;
	}

	public onScroll = (scrollTop: number, scrollLeft: number, timestamp?: number): void => {
		const clampedScrollLeft = Math.max(0, Math.min(this.state.cachedMaxScrollLeft, scrollLeft));
		if (clampedScrollLeft !== scrollLeft && this.deps.viewportRenderer.scrollViewport) {
			this.deps.viewportRenderer.scrollViewport.scrollLeft = clampedScrollLeft;
		}
		const changed = this.deps.engine.viewport.setScrollPosition(scrollTop, clampedScrollLeft, timestamp);
		if (!changed) return;
		this.markScrolling();
		this.deps.requestScrollFrame();
		// Scroll-end detection is now owned by FrameCoordinator (single RAF loop).
	};

	public updateCachedGeometryBoundsFromState(defaultColWidth: number, defaultRowHeight: number): void {
		this.state.cachedTotalWidth = this.deps.engine.geometry.getTotalWidth(defaultColWidth);
		this.state.cachedTotalHeight = this.deps.engine.geometry.getTotalHeight(defaultRowHeight);
		this.state.cachedDefaultRowHeight = defaultRowHeight ?? 40;
		const viewportWidth = this.deps.engine.viewport.scrollViewportClientWidth || this.deps.engine.viewport.viewportWidth;
		this.state.cachedMaxScrollLeft = Math.max(0, this.state.cachedTotalWidth - viewportWidth);
	}

	public flushScrollFrame = (): void => {
		const scrollViewport = this.deps.viewportRenderer.scrollViewport;
		if (!scrollViewport) return;
		this.deps.viewportRenderer.syncViewportScrollFromDom();

		const state = this.deps.engine.stateManager.getState();
		this.state.cachedHasSelectionOverlay = !!state.selection.bounds && !!this.deps.engine.getRowModel();
		this.updateCachedGeometryBoundsFromState(state.defaultColWidth, state.defaultRowHeight);

		const candidateIdx = 1 - this.state.activeRenderWindowBufIdx;
		const candidateBuf = this.state.renderWindowBufs[candidateIdx];
		computeRenderWindowInto(this.deps.engine, candidateBuf);
		const nextWindow = applyRenderWindowRuntimeLimits(candidateBuf, state.runtimeLimits);
		const layoutPlan = this.deps.syncLayoutPlan(nextWindow);

		if (sameRenderedWindow(this.deps.rowRenderer.currentWindow, nextWindow)) {
			this.deps.renderStats.scrollFrames++;
			this.deps.renderStats.sameWindowBailouts = (this.deps.renderStats.sameWindowBailouts || 0) + 1;
			// Phase is already scroll-frame (set by FrameCoordinator before calling this callback).
			// FrameCoordinator will transition to post-scroll in the finally block after we return.
			this.syncCheapScrollOnly(layoutPlan);
			return;
		}

		if (nextWindow === candidateBuf) {
			this.state.activeRenderWindowBufIdx = candidateIdx;
		}

		// Phase is already scroll-frame (set by FrameCoordinator before calling this callback).
		this.deps.rowRenderer.currentScrollCellsPatched = 0;
		this.deps.rowRenderer.currentScrollRowsRecycled = 0;
		this.deps.rowRenderer.currentScrollRowsVisited = 0;
		this.deps.rowRenderer.currentScrollRowsRebound = 0;
		this.deps.rowRenderer.currentScrollCellsVisited = 0;
		this.deps.rowRenderer.currentScrollCellsWritten = 0;
		this.deps.rowRenderer.currentScrollPortalOps = 0;
		this.deps.renderStats.scrollFrames++;
		const startStateReads = this.deps.engine.instrumentation.get(GridMetric.STATE_READS);
		try {
			const plan = this.deps.engine.columns.getCompiledPlan();
			const scrollCtx = this.state.scrollCtx;
			scrollCtx.state = state;
			scrollCtx.rowVersions = this.deps.engine.rowVersions;
			scrollCtx.globalVersion = state.globalVersion;
			scrollCtx.styleVersion = this.deps.rowRenderer.styleVersion;
			scrollCtx.loadingVersion = this.deps.rowRenderer.loadingVersion;
			scrollCtx.activeEdit = state.activeEdit;
			scrollCtx.hasDeferredCellStyleRules = compileStyleRules(state.styleRules).hasCellRules;
			scrollCtx.hasCustomRenderers = plan.hasCustomRenderers;
			scrollCtx.plan = plan;
			scrollCtx.visibleColRange.startIdx = nextWindow.colStart;
			scrollCtx.visibleColRange.endIdx = nextWindow.colEnd;
			const visibleColRange = scrollCtx.visibleColRange;
			scrollCtx.focusedCell = state.selection.focus;
			scrollCtx.selectionBounds = state.selection.bounds ?? undefined;

			this.deps.recycleViewport(true, scrollCtx, nextWindow);
			this.deps.stickyGroupRenderer.sync(layoutPlan);

			this.deps.headerRenderer.syncScrollLeft(layoutPlan);
			this.deps.floatingFilterRenderer.syncScrollLeft(layoutPlan);
			const didSyncRange = this.deps.headerRenderer.syncVisibleColumnRange(layoutPlan, visibleColRange);
			if (didSyncRange) {
				this.deps.renderStats.headerRangeSyncsDuringScroll++;
			}
			this.deps.renderStats.overlayCheapSyncsDuringScroll++;
			this.deps.overlayRenderer.syncScrollPosition(this.state.cachedHasSelectionOverlay);
		} finally {
			const stateReadsInFrame = this.deps.engine.instrumentation.get(GridMetric.STATE_READS) - startStateReads;
			this.deps.renderStats.stateReadsDuringScroll += stateReadsInFrame;
			if (this.deps.renderStats.cellsPatchedPerScrollFrame.length >= 1024) {
				this.deps.renderStats.cellsPatchedPerScrollFrame.length = 0;
			}
			if (this.deps.renderStats.rowsRecycledPerScrollFrame.length >= 1024) {
				this.deps.renderStats.rowsRecycledPerScrollFrame.length = 0;
			}
			this.deps.renderStats.cellsPatchedPerScrollFrame.push(this.deps.rowRenderer.currentScrollCellsPatched);
			this.deps.renderStats.rowsRecycledPerScrollFrame.push(this.deps.rowRenderer.currentScrollRowsRecycled);
			// FrameCoordinator transitions to post-scroll in its finally block after this callback returns.
		}
	};

	public markScrolling(): void {
		const wasScrolling = this.deps.runtimeState.isScrolling();
		const phase = this.deps.runtimeState.phase;
		if (!wasScrolling) {
			this.deps.viewportRenderer.setScrollingClass(true);
			this.deps.runtimeState.transitionTo('scroll-pending');
		} else if (phase === 'post-scroll') {
			// New scroll event during post-scroll window: re-enter scroll-pending (increments scrollEpoch).
			this.deps.runtimeState.transitionTo('scroll-pending');
		}
		this.clearPostScrollDecorationTimer();
		this.deps.layoutTransition.cancel();
		this.deps.rowRenderer.hoveredRowIndex = null;
	}

	public finishScrolling(): void {
		// FrameCoordinator has already transitioned to idle before calling this.
		this.deps.viewportRenderer.setScrollingClass(false);
		this.deps.rowRenderer.programmaticScrollCell = null;
		this.flushPendingPortalReleasesAfterScroll();
		this.state.needsPostScrollPortalFlush = this.state.needsPostScrollPortalFlush || this.deps.portalMountManager.getDeferredCount() > 0;
		if (this.state.needsPostScrollPortalFlush) {
			this.scheduleBudgetedPortalFlush();
		}
		this.restoreDeferredFocus();
		if (this.state.flushPendingAfterScroll) {
			this.state.flushPendingAfterScroll = false;
			this.deps.frameCoordinator.requestPostScrollWork();
		}
		if (
			this.state.viewportDirtyAfterScroll ||
			this.deps.rowRenderer.dirtyCellsAfterScroll.size > 0 ||
			this.deps.rowRenderer.dirtyRowsAfterScroll.size > 0
		) {
			this.state.viewportDirtyAfterScroll = false;
			this.scheduleBudgetedDecoration();
		}
		if (this.deps.overlayRenderer.overlayDirtyDuringScroll) {
			this.deps.overlayRenderer.overlayDirtyDuringScroll = false;
			this.deps.overlayRenderer.repaintOverlay();
		}
	}

	public flushPendingPortalReleasesAfterScroll(): void {
		if (this.deps.rowRenderer.pendingPortalReleasesAfterScroll.size === 0) return;
		const pending = Array.from(this.deps.rowRenderer.pendingPortalReleasesAfterScroll.values());
		this.deps.rowRenderer.pendingPortalReleasesAfterScroll.clear();
		this.deps.portalMountManager.releaseCells(pending, false);
		this.state.needsPostScrollPortalFlush = true;
	}

	public scheduleBudgetedPortalFlush(): void {
		if (this.state.portalFlushScheduled) return;
		this.state.portalFlushScheduled = true;
		this.deps.gridScheduler.idle((deadline) => {
			this.state.portalFlushScheduled = false;
			if (this.deps.runtimeState.isScrolling()) {
				this.state.needsPostScrollPortalFlush = true;
				return;
			}
			const result = this.deps.portalMountManager.flushDeferred({
				maxItems: this.state.portalFlushBudget,
				reason: 'scroll-idle',
				flushSync: false,
				deadline,
			});
			this.state.needsPostScrollPortalFlush = result.remaining > 0;
			if (result.remaining > 0) {
				this.scheduleBudgetedPortalFlush();
			}
		});
	}

	public clearPostScrollDecorationTimer(): void {
		if (this.state.postScrollDecorationTimer !== null) {
			this.deps.gridScheduler.cancelIdle(this.state.postScrollDecorationTimer);
			this.state.postScrollDecorationTimer = null;
		}
		this.state.postScrollDecorationScheduled = false;
	}

	public scheduleBudgetedDecoration(): void {
		if (this.state.postScrollDecorationScheduled) return;
		this.state.postScrollDecorationScheduled = true;
		this.state.postScrollDecorationTimer = this.deps.gridScheduler.idle(() => {
			this.state.postScrollDecorationTimer = null;
			this.state.postScrollDecorationScheduled = false;
			if (this.deps.runtimeState.isScrolling()) {
				return;
			}
			this.deps.renderStats.postScrollDecorationChunks++;
			this.deps.portalMountManager.beginCellReleaseTransaction();
			let result;
			try {
				result = this.deps.rowRenderer.decorateDirtyCellsAfterScroll({ maxCells: this.state.postScrollDecorationBudget });
			} finally {
				this.deps.portalMountManager.endCellReleaseTransaction();
			}
			if (result.processed > this.deps.renderStats.maxCellsDecoratedInOneChunk) {
				this.deps.renderStats.maxCellsDecoratedInOneChunk = result.processed;
			}
			this.deps.renderStats.cellsDecoratedAfterScroll += result.processed;
			if (result.remaining > 0) {
				this.scheduleBudgetedDecoration();
			}
		});
	}

	public restoreDeferredFocus(): void {
		const cell = this.deps.rowRenderer.deferredFocusCell;
		this.deps.rowRenderer.deferredFocusCell = null;
		if (!cell || !cell.isConnected) return;
		this.deps.rowRenderer.applyFocus(cell);
	}

	public syncCheapScrollOnly(layoutPlan: GridLayoutPlan): void {
		const window = layoutPlan.renderWindow;
		const scrollTop = layoutPlan.viewport.scrollTop;
		const scrollLeft = layoutPlan.viewport.scrollLeft;

		this.deps.headerRenderer.syncScrollLeft(layoutPlan);
		this.deps.floatingFilterRenderer.syncScrollLeft(layoutPlan);
		this.deps.renderStats.overlayCheapSyncsDuringScroll++;
		this.deps.overlayRenderer.syncScrollPosition(this.state.cachedHasSelectionOverlay);

		const pinTopRows = window.pinTopRows;
		const pinBottomRows = window.pinBottomRows;
		if (pinTopRows > 0 || pinBottomRows > 0) {
			const viewportHeight = this.deps.engine.viewport.viewportHeight;
			const totalHeight = this.state.cachedTotalHeight;
			const rowTops = this.deps.engine.geometry.rowTops;

			for (let r = 0; r < pinTopRows && r < window.rowCount; r++) {
				const slot = this.deps.rowRenderer.activeRows.get(r);
				if (slot) {
					slot.updatePosition(rowTops[r] + scrollTop);
				}
			}

			for (let r = window.rowCount - pinBottomRows; r < window.rowCount; r++) {
				if (r >= pinTopRows) {
					const slot = this.deps.rowRenderer.activeRows.get(r);
					if (slot) {
						slot.updatePosition(scrollTop + viewportHeight - (totalHeight - rowTops[r]));
					}
				}
			}
		}

		this.deps.stickyGroupRenderer.sync(layoutPlan);
		if (this.deps.rowRenderer.currentWindow) {
			this.deps.rowRenderer.currentWindow.scrollTop = scrollTop;
			this.deps.rowRenderer.currentWindow.scrollLeft = scrollLeft;
		}
	}
}
