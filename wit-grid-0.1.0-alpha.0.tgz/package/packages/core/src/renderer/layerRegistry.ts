import type { GridLayoutPlan } from './layoutPlan.js';

/**
 * Declarative DOM-layer registry.
 *
 * Every structural layer the grid mounts is described here once: its class, its
 * parent, its sibling order, and a pure `apply(el, plan)` that positions/sizes it
 * from the layout plan — never from magic pixel constants. `ViewportRenderer` builds
 * the DOM by iterating this table and re-positions every layer by looping it again on
 * each `syncLayoutPlan`. New layers (status bar, pagination, find-bar, side panels)
 * slot in by adding a descriptor here plus a renderer — with no edits to the mount or
 * sync bodies.
 *
 * Invariants enforced by guard tests:
 *  - Every `.og-layer-*` element in the DOM corresponds to a registry entry.
 *  - No renderer sets a layer's structural top/height/width outside its `apply`.
 */

/** A parent is one of the two DOM roots, or another layer's `id`. */
export type LayerParentRef = 'scroll-viewport' | 'container' | string;

export interface LayerDescriptor {
	/** Stable id used for parent references and named lookup. */
	id: string;
	className: string;
	parent: LayerParentRef;
	/** Sibling order within the parent (ascending). */
	order: number;
	/** One-time inline setup at mount that does not depend on the plan. */
	init?(el: HTMLDivElement): void;
	/** Position/size purely from the layout plan. Runs on every syncLayoutPlan. */
	apply?(el: HTMLDivElement, plan: GridLayoutPlan): void;
}

export const LAYER_REGISTRY: LayerDescriptor[] = [
	{
		id: 'group-panel',
		className: 'og-group-panel',
		parent: 'scroll-viewport',
		order: 0,
		init(el) {
			el.style.display = 'none';
		},
		apply(el, plan) {
			const visible = plan.chrome.groupPanelHeight > 0;
			el.style.display = visible ? 'flex' : 'none';
			el.style.height = visible ? `${plan.chrome.groupPanelHeight}px` : '0';
			el.style.width = `${plan.dimensions.contentWidth}px`;
		},
	},
	{
		id: 'filter-chip-bar',
		className: 'og-filter-chip-bar',
		parent: 'scroll-viewport',
		order: 1,
		init(el) {
			el.style.display = 'none';
		},
		apply(el, plan) {
			const visible = plan.chrome.filterChipBarHeight > 0;
			el.style.display = visible ? 'flex' : 'none';
			el.style.top = `${plan.chrome.groupPanelHeight}px`;
			el.style.height = visible ? `${plan.chrome.filterChipBarHeight}px` : '0';
			el.style.width = `${plan.dimensions.contentWidth}px`;
		},
	},
	{
		id: 'header-wrapper',
		className: 'og-layer-header-wrapper',
		parent: 'scroll-viewport',
		order: 2,
		apply(el, plan) {
			el.style.top = `${plan.origins.headerTop}px`;
			el.style.height = `${plan.chrome.totalHeaderHeight}px`;
			el.style.width = `${plan.dimensions.contentWidth}px`;
		},
	},
	{
		id: 'header',
		className: 'og-layer-header',
		parent: 'header-wrapper',
		order: 0,
		apply(el, plan) {
			el.style.width = `${plan.dimensions.contentWidth}px`;
		},
	},
	{
		id: 'header-left',
		className: 'og-layer-header-left',
		parent: 'header-wrapper',
		order: 1,
		apply(el, plan) {
			el.style.width = `${plan.columns.pinLeftWidth}px`;
		},
	},
	{
		id: 'header-right',
		className: 'og-layer-header-right',
		parent: 'header-wrapper',
		order: 2,
		apply(el, plan) {
			el.style.width = `${plan.columns.pinRightWidth}px`;
		},
	},
	// Floating filter row — always-visible inline filter inputs below the header.
	// Mirrors the header's three-lane pattern: center columns are horizontally virtualised,
	// pinned columns always rendered.
	{
		id: 'floating-filter-wrapper',
		className: 'og-layer-floating-filter-wrapper',
		parent: 'scroll-viewport',
		order: 3,
		init(el) {
			el.style.display = 'none';
		},
		apply(el, plan) {
			const visible = plan.chrome.floatingFilterHeight > 0;
			el.style.display = visible ? 'flex' : 'none';
			el.style.top = `${plan.origins.headerTop + plan.chrome.totalHeaderHeight}px`;
			el.style.height = `${plan.chrome.floatingFilterHeight}px`;
			el.style.width = `${plan.dimensions.contentWidth}px`;
		},
	},
	{
		id: 'floating-filter',
		className: 'og-layer-floating-filter',
		parent: 'floating-filter-wrapper',
		order: 0,
		apply(el, plan) {
			el.style.width = `${plan.dimensions.contentWidth}px`;
		},
	},
	{
		id: 'floating-filter-left',
		className: 'og-layer-floating-filter-left',
		parent: 'floating-filter-wrapper',
		order: 1,
		apply(el, plan) {
			el.style.width = `${plan.columns.pinLeftWidth}px`;
		},
	},
	{
		id: 'floating-filter-right',
		className: 'og-layer-floating-filter-right',
		parent: 'floating-filter-wrapper',
		order: 2,
		apply(el, plan) {
			el.style.width = `${plan.columns.pinRightWidth}px`;
		},
	},
	{
		id: 'sticky-groups',
		className: 'og-layer-sticky-groups',
		parent: 'scroll-viewport',
		order: 4,
		apply(el, plan) {
			el.style.width = `${plan.dimensions.contentWidth}px`;
			el.style.transform = `translate3d(0, ${plan.origins.stickyGroupLayerTop}px, 0)`;
		},
	},
	{
		id: 'rows',
		className: 'og-rows-container',
		parent: 'scroll-viewport',
		order: 5,
		apply(el, plan) {
			el.style.height = `${plan.dimensions.contentHeight}px`;
			el.style.width = `${plan.dimensions.contentWidth}px`;
		},
	},
	// Exit-animation overlay — holds short-lived clone "ghosts" of rows that left the model
	// (e.g. collapsed group children) while they fade out. Lives in the rows' content
	// coordinate space (ghosts carry their own translateY), is pointer-inert, and is purely
	// a CSS overlay — no plan-driven positioning, so no apply().
	{
		id: 'exiting',
		className: 'og-layer-exiting',
		parent: 'rows',
		order: 0,
	},
	{
		id: 'overlay',
		className: 'og-layer-overlay',
		parent: 'container',
		order: 1,
		apply(el, plan) {
			el.style.top = `${plan.origins.overlayTop}px`;
		},
	},
	// Bottom chrome — fixed bars docked below the scroll viewport, parented to the grid
	// container (not the scroll viewport) so they never scroll. They occupy the space
	// the scroll viewport gives up via --og-bottom-chrome-height.
	{
		id: 'status-bar',
		className: 'og-layer-status-bar',
		parent: 'container',
		order: 2,
		apply(el, plan) {
			const visible = plan.chrome.statusBarHeight > 0;
			el.style.display = visible ? 'flex' : 'none';
			el.style.top = `${plan.origins.statusBarTop}px`;
			el.style.height = `${plan.chrome.statusBarHeight}px`;
		},
	},
	{
		id: 'pagination',
		className: 'og-layer-pagination',
		parent: 'container',
		order: 3,
		apply(el, plan) {
			const visible = plan.chrome.paginationHeight > 0;
			el.style.display = visible ? 'flex' : 'none';
			el.style.top = `${plan.origins.paginationTop}px`;
			el.style.height = `${plan.chrome.paginationHeight}px`;
		},
	},
];
