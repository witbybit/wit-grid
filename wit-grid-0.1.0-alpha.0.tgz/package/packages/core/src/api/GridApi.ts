import type { FilterModel, SortModel } from '../rowModel.js';
import type { GridDomainVersions } from '../state/GridDomainVersions.js';
import type { GridRuntimePorts, RuntimePortBinding, RuntimePortBindResult } from '../engine/rendererPorts.js';
import type { IGridDatasource } from '../serverRowModel.js';
import type { ColumnDef, GridStyleRule, CellRendererPhase } from '../columnDef.js';
import type { VisualRow } from '../visualRow.js';
import type { RowNode } from '../rowNode.js';
import type { ViewportRange } from '../viewportController.js';
import type { RenderStats } from '../renderer/renderOrchestrator.js';
import type { AggregationDef } from '../rowModel.js';
import type { PersistenceStatus, PersistedGridState } from '../persistence/statePersistence.js';
import type { CsvExportOptions } from '../export/csvExport.js';
import type { GridEventPayloadMap, GridEventListener } from './GridEvents.js';
import type { RuntimeFault, RuntimeFaultInput } from '../diagnostics/RuntimeFaultReporter.js';
import type { GridInstrumentation } from '../diagnostics/GridInstrumentation.js';
import type { ColumnState, GridCellRangeBounds } from '../state/GridState.js';
import type { BuiltInThemeName, ThemeTokens } from '../renderer/themes.js';

export type { CsvExportOptions };
export type { RuntimeFault };

// ── Validation types ──────────────────────────────────────────────────────────

export interface CellValidationError {
	rowId: string;
	colField: string;
	error: string;
}

/** Parameters passed to a grid-level row validator. */
export interface RowValidatorParams<TRowData = unknown> {
	/** Current row data snapshot. */
	row: TRowData;
	/**
	 * Which column triggered this validation call (set during single-cell validation,
	 * undefined during a full grid validateGrid() sweep).
	 */
	changedColField?: string;
}

/**
 * Grid-level cross-field validator. Return a map of colField → error string (or null/empty
 * to clear a row-level error for that field). Runs after per-column valueValidators so it can
 * override or supplement them.
 */
export type RowValidator<TRowData = unknown> = (
	params: RowValidatorParams<TRowData>
) => Record<string, string | null> | Promise<Record<string, string | null>>;

// ── Cell / selection types ────────────────────────────────────────────────────

export interface CellSubscription {
	rowId: string;
	colField: string;
	onStoreChange: () => void;
}

export interface GridCellPointer {
	rowId: string;
	colField: string;
}

/** Extended pointer used for the active edit slot — carries optional validation state. */
export interface ActiveEditState extends GridCellPointer {
	/** Non-null when validation has failed; shown below the cell editor. */
	validationError?: string | null;
}

export interface CellPointer {
	rowId: string;
	colId: string;
}

/** A single cell value write in a batch update operation. */
export interface BatchCellValueUpdate {
	rowId: string;
	colField: string;
	value: unknown;
}

export interface VisualRowPointer {
	visualRowId: string;
}

export interface SelectionChangeResult {
	invalidatedCells: GridCellPointer[];
	invalidatedRows: string[];
	overlayChanged: boolean;
}

export type RowSelectionGestureSource = 'api' | 'checkbox' | 'headerCheckbox' | 'pointer' | 'keyboard';
export type RowSelectionGestureKind = 'replace' | 'select' | 'deselect' | 'toggle' | 'selectAll' | 'clear';
export type RowSelectionMode = 'single' | 'multiple';
export type RowSelectionScope = 'page' | 'loaded' | 'filtered' | 'all';

export interface RowSelectionOptions {
	mode: RowSelectionMode;
	/** Scope used by the built-in header checkbox and api.selectAllRows() when no scope is passed. */
	selectAllScope?: RowSelectionScope;
}

export interface SelectRowsOptions {
	mode?: 'add' | 'replace';
}

export interface SelectAllRowsOptions {
	scope?: RowSelectionScope;
	mode?: 'add' | 'replace';
}

export interface RowSelectionGesture {
	kind: RowSelectionGestureKind;
	rowIds?: string[];
	source?: RowSelectionGestureSource;
	scope?: RowSelectionScope;
	mode?: 'add' | 'replace';
}

export interface RowSelectionChangeResult {
	selectedRowIds: string[];
	changedRowIds: string[];
	addedRowIds: string[];
	removedRowIds: string[];
	source: RowSelectionGestureSource;
}

export interface GridCellCoordinates {
	rowIndex: number;
	colIndex: number;
}

export type GridSelectionSource = 'api' | 'keyboard' | 'pointer' | 'fill' | 'program';

export interface GridCellRange {
	start: GridCellPointer;
	end: GridCellPointer;
}

export interface GridSelectionState {
	focus: GridCellPointer | null;
	anchor: GridCellPointer | null;
	range: GridCellRange | null;
	bounds: GridCellRangeBounds | null;
	source: GridSelectionSource;
}

export interface GridStateSnapshot<TRowData = unknown> {
	readonly columns: readonly ColumnDef<TRowData>[];
	readonly sortModel: SortModel | null;
	readonly filterModel: FilterModel | null;
	readonly selection: GridSelectionState;
	readonly selectedRowIds: readonly string[];
	readonly activeEdit: ActiveEditState | null;
	readonly loading?: boolean;
	readonly pagination?: { pageSize: number; page?: number };
	readonly enableColumnReorder: boolean;
	readonly themeName?: BuiltInThemeName;
	readonly sidebarOpenPanel?: string | null;
	readonly chartOpen?: boolean;
	readonly groupBy?: readonly string[];
	readonly showGroupFooter?: boolean;
	readonly enableStickyGroupRows?: boolean;
	readonly masterDetailEnabled?: boolean;
}

export type GridSnapshotListener<TRowData = unknown> = (snapshot: GridStateSnapshot<TRowData>) => void;

export type GridSnapshotKeyListener<TRowData = unknown, K extends keyof GridStateSnapshot<TRowData> = keyof GridStateSnapshot<TRowData>> = (
	value: GridStateSnapshot<TRowData>[K]
) => void;

export interface GridPlugin<TRowData = unknown> {
	readonly name: string;
	onInit?(api: GridPluginRuntime<TRowData>): void;
	onMount?(): void;
	onDestroy?(): void;
	onViewportChange?(range: ViewportRange): void;
}

export interface GridCellClickParams<TRowData = unknown> {
	rowId: string;
	rowIndex: number;
	row: TRowData | null;
	node: RowNode<TRowData> | null;
	colField: string;
	colIndex: number;
	column: ColumnDef<TRowData>;
	value: unknown;
	api: GridApi<TRowData>;
	event: MouseEvent;
}

export interface GridCellAccess<TRowData = unknown> {
	rowId: string;
	rowIndex: number;
	row: TRowData | null;
	node: RowNode<TRowData> | null;
	colField: string;
	colIndex: number;
	column: ColumnDef<TRowData>;
	value: unknown;
	rawValue: unknown;
	isFocused: boolean;
	isRowFocused: boolean;
	isSelected: boolean;
	isRowSelected: boolean;
	isEditing: boolean;
	isLoading: boolean;
	event?: Event;
}

export interface CellState {
	value: unknown;
	computedValue?: unknown;
	isEditing?: boolean;
}

export interface GridRowsAccessor<TRowData = unknown> {
	/** Iterate over all active data rows */
	forEach(callback: (row: TRowData, index: number) => void): void;
	/** Get all active data rows as an array */
	getAll(): TRowData[];
	/** Get currently selected data rows */
	getSelected(): TRowData[];
	/** Get currently selected row IDs */
	getSelectedIds(): string[];
	/** Get a data row by its ID */
	getById(id: string): TRowData | null;
	/** Get a row node by its ID */
	getNodeById(id: string): RowNode<TRowData> | null;
	/** Get the total number of data rows */
	getCount(): number;
	/** Get the visual representation of a row by its ID */
	getVisualRowById(id: string): VisualRow<TRowData> | null;
	/** Get helpers for rows within a specific cell/selection range */
	inRange(range: GridCellRange): {
		forEach(callback: (rowId: string, index: number) => void): void;
		getIds(): string[];
		getData(): TRowData[];
	};
	/** Get data rows that have been row-selected (checkbox/Ctrl+Click) */
	getChecked(): TRowData[];
	/** Get IDs of row-selected rows */
	getCheckedIds(): string[];
}

export interface AutoSizeColumnOptions {
	/** Include the header label in the measurement. Default: true */
	includeHeader?: boolean;
	/** Maximum number of rows to sample. Default: 500 */
	maxRows?: number;
	/** Extra pixels added to each side of the measured text width. Default: 8 */
	padding?: number;
}

export interface AutoSizeAllColumnsOptions extends AutoSizeColumnOptions {
	/** Skip pinned columns. Default: false */
	skipPinned?: boolean;
}

export interface RowDataTransaction<TData = unknown> {
	/** Rows to add. Optional `addIndex` controls insertion position (default: end). */
	add?: TData[];
	/** Index at which to insert added rows. Defaults to appending at the end. */
	addIndex?: number;
	/** Rows to remove, matched by row ID. */
	remove?: TData[];
	/** Rows to update, matched by row ID. Only changed fields are notified. */
	update?: TData[];
}

export interface RowNodeTransaction<TData = unknown> {
	add: RowNode<TData>[];
	remove: RowNode<TData>[];
	update: RowNode<TData>[];
}

export interface GridTransaction<TRowData = unknown> {
	columns?: ColumnDef<TRowData>[];
	rows?: TRowData[];
	rowTransaction?: RowDataTransaction<TRowData>;
	sortModel?: SortModel | null;
	filterModel?: FilterModel | null;
	pins?: { left?: number; right?: number; top?: number; bottom?: number };
}

// Re-export stable state-adjacent types so importers of GridApi.ts also get them.
export type { ColumnState, GridCellRangeBounds };

// ── Cell renderer / editor props ─────────────────────────────────────────────

/**
 * Props passed to every custom cell renderer component.
 *
 * @typeParam TRowData - Shape of the row data object.
 * @typeParam TValue   - Type of the cell value (defaults to `unknown`; narrow it
 *                       to get typed `value` inside your renderer, e.g.
 *                       `CellRendererProps<MyRow, string>`).
 */
export interface CellRendererProps<TRowData = unknown, TValue = unknown> {
	value: TValue;
	computedValue: TValue;
	row: TRowData;
	rowId: string;
	colField: string;
	colId?: string;
	isScrolling?: boolean;
	phase?: CellRendererPhase;
	isFocused?: boolean;
	isEditing?: boolean;
	isSelected?: boolean;
	api: GridApi<TRowData>;
}

/**
 * Props passed to every custom cell editor component.
 *
 * @typeParam TRowData - Shape of the row data object.
 * @typeParam TValue   - Type of the cell value (defaults to `unknown`; narrow it
 *                       to avoid casting inside your editor, e.g.
 *                       `CellEditorProps<MyRow, string>`).
 *
 * @example Typed string editor
 * ```tsx
 * const MyEditor = ({ value, onCommit, onCancel }: CellEditorProps<MyRow, string>) => (
 *   <input
 *     autoFocus
 *     defaultValue={value}
 *     onBlur={(e) => onCommit(e.target.value)}
 *     onKeyDown={(e) => { if (e.key === 'Escape') onCancel(); }}
 *   />
 * );
 * ```
 */
export interface CellEditorProps<TRowData = unknown, TValue = unknown> {
	rowId: string;
	colField: string;
	value: TValue;
	/**
	 * Update the local editing value without committing.
	 * Use this for text inputs where the user is still typing.
	 */
	onChange: (value: TValue) => void;
	api: GridApi<TRowData>;
	/**
	 * Commit the value and exit edit mode.
	 * If no value is passed, commits the last value set via `onChange`.
	 */
	onCommit: (finalValue?: TValue) => void;
	/**
	 * Cancel editing and revert to the original value.
	 */
	onCancel: () => void;
}

export interface HeaderMenuRendererProps<TRowData = unknown> {
	colField: string;
	column: ColumnDef<TRowData>;
	api: GridApi<TRowData>;
	close: () => void;
	container: HTMLDivElement;
}

/**
 * Public, pristine API intended for application developers.
 */
export interface GridApi<TRowData = unknown> {
	getStateSnapshot(): GridStateSnapshot<TRowData>;
	getRowId(row: TRowData): string;
	isRowLoading(rowId: string): boolean;
	getDataRowAtVisualIndex(index: number): TRowData | null;
	getDataRowNodeAtVisualIndex(index: number): RowNode<TRowData> | null;
	setRows(rows: TRowData[]): void;
	updateRows(updater: (rows: TRowData[]) => TRowData[]): void;
	applyTransaction(transaction: RowDataTransaction<TRowData>): RowNodeTransaction<TRowData> | null;
	/** Returns the current row order as an array of row IDs (source order, unfiltered). */
	getRowOrder(): string[];
	/** Reorder rows programmatically. All IDs must belong to existing rows; unknown IDs are silently dropped. */
	setRowOrder(rowIds: string[]): void;
	refreshRows(): void;
	setRowHeights: (rowHeights: Record<string, number> | undefined) => void;
	setDefaultRowHeight: (defaultRowHeight?: number | undefined) => void;
	purgeCache(): void;
	setServerDatasource(datasource: IGridDatasource<TRowData>, blockSize?: number): void;
	goToPage(page: number): void;
	getCellValue(rowId: string, colField: string): unknown;
	/** @experimental Formula/DAG engine (incubating) — DagEngine is directly coupled into GridEngine; must be extracted before Plan 097. Returns the formula string for a cell, or undefined if none. */
	getFormula(rowId: string, colField: string): string | undefined;
	/** @experimental Formula/DAG engine (incubating). Returns true when a formula is registered for the cell. */
	hasFormula(rowId: string, colField: string): boolean;
	/**
	 * @experimental Formula/DAG engine (incubating) — contract may change before alpha.
	 * Register a formula on a cell. The string must start with `=`.
	 * Throws if the formula introduces a circular dependency.
	 */
	setFormula(rowId: string, colField: string, formula: string): void;
	/** @experimental Formula/DAG engine (incubating). Remove the formula from a cell; raw stored value is retained. */
	clearFormula(rowId: string, colField: string): void;
	/**
	 * Updates a single cell value. Triggers valueSetter, undo history, and formula recalculation.
	 *
	 * For bulk mutations prefer `updateRows` (functional mapper) or `applyTransaction`
	 * (structured add/remove/update). Calling this in a loop fires O(N) individual
	 * invalidations instead of one coalesced batch.
	 */
	setCellValue(rowId: string, colField: string, value: unknown): void;
	/**
	 * Applies multiple cell value writes as a single atomic operation.
	 * valueSetter runs per-cell, but notifications, cellValueChanged events, and undo
	 * are coalesced — one RAF flush and one undo entry for the entire batch.
	 * Use this instead of looping setCellValue for paste, clear, and programmatic bulk edits.
	 */
	batchCellValues(updates: BatchCellValueUpdate[], source?: 'paste' | 'api' | 'fill'): void;
	selectCell(pointer: GridCellPointer | null, source?: GridSelectionSource): void;
	selectRange(start: GridCellPointer | null, end: GridCellPointer | null, source?: GridSelectionSource): void;
	extendSelection(end: GridCellPointer, source?: GridSelectionSource): void;
	// Row node multi-select
	applyRowSelectionGesture(gesture: RowSelectionGesture): RowSelectionChangeResult | null;
	selectRows(rowIds: string[], options?: SelectRowsOptions): void;
	deselectRows(rowIds: string[]): void;
	toggleRowSelection(rowId: string): void;
	selectAllRows(options?: SelectAllRowsOptions): void;
	clearRowSelection(): void;
	getSelectedRowIds(): string[];
	isRowNodeSelected(rowId: string): boolean;
	getSelectedRowCount(): number;
	setColumns(columns: ColumnDef<TRowData>[]): void;
	setColumnWidth(colField: string, width: number): void;
	/**
	 * Resize a column to fit its content by measuring rendered text on an offscreen canvas.
	 * Respects `minWidth` / `maxWidth` and `valueFormatter` output.
	 */
	autoSizeColumn(colField: string, options?: AutoSizeColumnOptions): void;
	/** Resize all visible columns to fit their content. */
	autoSizeAllColumns(options?: AutoSizeAllColumnsOptions): void;
	/** Copy the current cell selection to the clipboard as TSV. */
	copySelectedRange(): Promise<void>;
	/** Paste TSV text from clipboard into the grid starting at the current focus/selection. */
	pasteFromClipboard(): Promise<void>;
	/** Copy a specific visual row/column range to the clipboard as TSV. */
	copyRange(minRow: number, maxRow: number, minCol: number, maxCol: number): Promise<void>;
	setColumnVisible(colField: string, visible: boolean): void;
	setColumnsVisible(colFields: string[], visible: boolean): void;
	getColumns(): ColumnDef<TRowData>[];
	getDisplayedColumns(): ColumnDef<TRowData>[];
	setPinnedColumns(pins: { left?: number; right?: number }): void;
	getPinnedColumns(): { left: number; right: number };
	moveColumn(colField: string, toIndex: number): void;
	setColumnOrder(colFields: string[]): void;
	setColumnReorderEnabled(enabled: boolean): void;
	setRowHeight(rowId: string, height: number): void;
	setSortModel(sortModel: SortModel | null): void;
	setFilterModel(filterModel: FilterModel | null): void;
	/** Returns all distinct values for a column, scanning unfiltered row data. Used to populate set filter options. */
	getColumnDistinctValues(colField: string): (string | number | null)[];
	setStyleRules(styleRules: GridStyleRule<TRowData>[] | undefined): void;
	setGroupBy(colIds: string[]): void;
	getGroupBy(): string[];
	addGroupBy(colId: string, atIndex?: number): void;
	removeGroupBy(colId: string): void;
	moveGroupBy(colId: string, toIndex: number): void;
	setAggDefs(defs: AggregationDef<TRowData>[]): void;
	getAggDefs(): AggregationDef<TRowData>[];
	expandAllGroups(): void;
	collapseAllGroups(): void;
	setShowGroupFooter(enabled: boolean): void;
	setStickyGroupRows(enabled: boolean): void;
	setShowGroupPanel(enabled: boolean): void;
	/** Toggle the floating filter row (always-visible inline filter inputs below column headers). */
	setShowFloatingFilters(enabled: boolean): void;
	setShowFilterChipBar(enabled: boolean): void;
	toggleGroupExpanded(groupId: string): void;
	toggleDetailExpanded(rowId: string): void;
	isGroupExpanded(groupId: string): boolean;
	isDetailExpanded(rowId: string): boolean;
	getRowNodeById(rowId: string): RowNode<TRowData> | null;
	getRawRowById(rowId: string): TRowData | null;
	rows(): GridRowsAccessor<TRowData>;
	addEventListener<K extends keyof GridEventPayloadMap<TRowData>>(
		type: K,
		callback: GridEventListener<GridEventPayloadMap<TRowData>[K]>
	): () => void;
	dispatchEvent<K extends keyof GridEventPayloadMap<TRowData>>(type: K, payload: GridEventPayloadMap<TRowData>[K]): void;
	startEditing(rowId: string, colField: string): void;
	stopEditing(cancel?: boolean): void;
	/**
	 * Async commit of an in-progress edit.
	 * Runs `valueValidator` first (if defined). If validation passes, optimistically applies the
	 * value, then runs `valueSetter` (if defined). If the setter rejects, rolls back and surfaces
	 * a validation error on `activeEdit.validationError`.
	 * Returns true when the commit succeeded and `stopEditing` was called.
	 */
	commitEdit(rowId: string, colField: string, value: unknown): Promise<boolean>;

	// ── Validation API ────────────────────────────────────────────────────────
	/**
	 * Validate a single cell by running its column's `valueValidator` against the current value.
	 * Sets a persistent red-border indicator on failure; clears it on pass.
	 * Returns the error message string, or null when the cell is valid.
	 */
	validateCell(rowId: string, colField: string): Promise<string | null>;
	/**
	 * Run all column validators across every data row.
	 * Returns the list of failures. Visual error indicators are applied to all failing cells
	 * and `gridValidated` is fired with the full result.
	 */
	validateGrid(): Promise<CellValidationError[]>;
	/** Set a validation error on a cell from an external source (e.g. server response, external form library). */
	setCellValidationError(rowId: string, colField: string, error: string): void;
	/** Clear the validation error for a single cell. */
	clearCellValidationError(rowId: string, colField: string): void;
	/** Clear all validation errors on the grid. */
	clearValidationErrors(): void;
	/** Returns the current validation error message for a cell, or null if none. */
	getCellValidationError(rowId: string, colField: string): string | null;
	/** Returns true when at least one cell has an active validation error. */
	hasValidationErrors(): boolean;
	/** Returns all current validation errors without re-running validation. */
	getAllValidationErrors(): CellValidationError[];
	/**
	 * Returns the currently rendered column range for the center (scrollable) lane.
	 * `colStart` and `colEnd` are column indices; `total` is the total column count.
	 * Useful for displaying a "Visible columns: X / Y" badge or driving custom overlays.
	 * Returns `{colStart: 0, colEnd: 0, total: 0}` before the first render.
	 */
	getVisibleColumnRange(): { colStart: number; colEnd: number; total: number };
	/** Returns a per-column snapshot of the current user-configurable state (width, visibility, pinning, sort) in column order. */
	getColumnState(): ColumnState[];
	/** Apply a partial column state array. Only fields present in `states` are updated; others are unchanged.
	 *  Pass `{ applyOrder: true }` to also restore column order from the array. */
	applyColumnState(states: ColumnState[], opts?: { applyOrder?: boolean }): void;
	/** Returns a full serializable snapshot of the current grid state (columns, sort, filter, grouping, pinning). */
	getGridState(): PersistedGridState;
	/** Apply a serializable grid state snapshot, updating all covered fields. Unknown fields are ignored. */
	applyGridState(state: PersistedGridState): void;
	subscribe(listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToKey<K extends keyof GridStateSnapshot<TRowData>>(key: K, listener: GridSnapshotKeyListener<TRowData, K>): () => void;
	/** Subscribe to domain version changes. Fires once per committed logical mutation in any domain.
	 *  Prefer this over broad `subscribe()` for consumers that only need to know *that* something changed. */
	subscribeToDomainVersions(listener: (v: GridDomainVersions) => void): () => void;
	/** Subscribe to version increments for a single domain. The listener receives the new version counter
	 *  each time that domain is mutated. More targeted than `subscribeToDomainVersions`. */
	subscribeDomain(domain: keyof GridDomainVersions, listener: (version: number) => void): () => void;
	getColumnIndex(colField: string): number;
	getColumnField(colIndex: number): string | null;
	getColumnDef(colField: string): ColumnDef<TRowData> | undefined;
	/** @experimental Undo/redo (incubating) — coverage limited to cell edits; contract may change. */
	undo(): void;
	/** @experimental Undo/redo (incubating) — coverage limited to cell edits; contract may change. */
	redo(): void;
	/** @experimental Undo/redo (incubating). */
	canUndo(): boolean;
	/** @experimental Undo/redo (incubating). */
	canRedo(): boolean;
	/** @experimental Sidebar panel (incubating) — API may change before alpha. */
	openPanel(panelId: string): void;
	/** @experimental Sidebar panel (incubating). */
	closePanel(): void;
	/** @experimental Sidebar panel (incubating). */
	togglePanel(panelId: string): void;
	/** @experimental Sidebar panel (incubating). */
	getOpenPanel(): string | null;
	/** @experimental Chart overlay (incubating) — no chart renderer in core; candidate for removal before Plan 103. */
	openChart(): void;
	/** @experimental Chart overlay (incubating). */
	closeChart(): void;
	/** @experimental Chart overlay (incubating). */
	toggleChart(): void;
	/** @experimental Chart overlay (incubating). */
	isChartOpen(): boolean;
	exportCsv(options?: CsvExportOptions): void;
	/** Returns true when a persistence adapter is configured for this grid instance. */
	hasPersistence(): boolean;
	/** Clear all persisted state saved by the configured persistence adapter. No-op when no adapter is set. */
	clearPersistedState(): void | Promise<void>;
	/** Enable or disable auto-save. When disabled, state changes are not persisted until re-enabled. */
	setAutoSave(enabled: boolean): void;
	/** Returns whether auto-save is currently enabled. */
	isAutoSaveEnabled(): boolean;
	/** Returns the current persistence save status. */
	getPersistenceStatus(): PersistenceStatus;
	/** Subscribe to persistence status changes. Fires immediately when saving starts/ends or errors. */
	subscribeToPersistenceStatus(listener: (status: PersistenceStatus) => void): () => void;
	/** Immediately save current state, bypassing the debounce timer. No-op when no adapter is set. */
	saveNow(): void;
	/** Returns a bounded snapshot of recent runtime faults captured by the grid core. */
	getRuntimeFaults(): RuntimeFault[];
	/** Clears the captured runtime fault history. */
	clearRuntimeFaults(): void;
	/** Synchronously flushes all pending cell update notifications. Use when you need to ensure repaints happen before the next frame. */
	flushCellUpdatesSync(): void;
	/** Returns the active instrumentation sink. Replace with a RecordingGridInstrumentation for diagnostics or tests. */
	getInstrumentation(): GridInstrumentation;
	/** Swap the active instrumentation sink. Provide NOOP_INSTRUMENTATION to disable recording. */
	setInstrumentation(inst: GridInstrumentation): void;

	// ── Theme API ──────────────────────────────────────────────────────────────
	/** Returns the currently active theme tokens. */
	getTheme(): ThemeTokens;
	/** Returns the active built-in theme name, or null when a custom theme is active. */
	getThemeName(): BuiltInThemeName | null;
	/** Returns the built-in themes supported by this build. */
	getAvailableThemes(): BuiltInThemeName[];
	/** Switch to a built-in theme by name ('light', 'dark', 'cool-blue', etc). */
	switchTheme(themeName: string): void;
	/** Shallow-merge partial theme tokens into the current theme. Ideal for live tweaking without a full theme switch. */
	mergeTheme(partial: Partial<ThemeTokens>): void;
	/** Subscribe to theme changes. Returns an unsubscribe function. */
	onThemeChange(listener: (theme: ThemeTokens) => void): () => void;
	/** Returns the grid container HTML element, or null if not mounted yet. */
	getContainer(): HTMLElement | null;

	destroy(): void;
}

export interface GridPluginRuntime<TRowData = unknown> extends GridApi<TRowData> {
	getCellState(rowId: string, colField: string): CellState;
	getCheapDisplayValue(rowId: string, colField: string): string;
	getVisualRow(index: number): VisualRow<TRowData> | null;
	getVisualRowCount(): number;
	getVisualIndexByRowId(rowId: string): number | null;
	getColumnIndex(colField: string): number;
	getColumnField(colIndex: number): string | null;
	getRowModel(): import('../store.js').RowModel<TRowData> | null;
	reportRuntimeFault(fault: RuntimeFaultInput): RuntimeFault;
}

export interface GridPluginController<TRowData = unknown> {
	registerPlugin(plugin: GridPlugin<TRowData>): void;
	getPlugin<T = unknown>(name: string): T | null;
	unregisterPlugin(name: string): void;
}

export interface GridRendererApi<TRowData = unknown> extends GridApi<TRowData> {
	getCachedDisplayValue(rowId: string, colField: string): string | undefined;
	getCheapDisplayValue(rowId: string, colField: string): string;
	getComputedCellValue(rowId: string, colField: string): unknown;
	getCellState(rowId: string, colField: string): CellState;
	getCellAccess(rowId: string, colField: string): GridCellAccess<TRowData> | null;
	getRowOverscanPx(): number;
	setRowOverscanPx(px: number): void;
	getVisualRow(index: number): VisualRow<TRowData> | null;
	getVisualRowCount(): number;
	getVisualIndexById(visualRowId: string): number | null;
	getVisualIndexByRowId(rowId: string): number | null;
	subscribeToViewport(listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToSelection(listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToFocusedCell(listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToEditingCell(listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToCell(rowId: string, colField: string, listener: () => void): () => void;
	subscribeToRow(rowId: string, listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToColumn(colField: string, listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToHeaders(listener: GridSnapshotListener<TRowData>): () => void;
}

export interface GridHostRuntime<TRowData = unknown> {
	getRenderStats(): RenderStats;
	resetRenderStats(): void;
	setViewportPins(pins: { left?: number; right?: number; top?: number; bottom?: number }): void;
	setViewportSize(width: number, height: number): boolean;
	updateVisibleRanges(): boolean;
	/** Bind live runtime ports for an active host. Returns a result; ok=false means rejected (already-bound or destroyed). */
	bindRuntimePorts(ports: GridRuntimePorts): RuntimePortBindResult;
	/** Unbind the active host and restore headless ports. Stale tokens report a fault and no-op. */
	unbindRuntimePorts(binding: RuntimePortBinding): void;
	/** Returns true if this binding token corresponds to the currently active host. */
	isBindingCurrent(binding: RuntimePortBinding): boolean;
}

export interface GridStoreRuntime<TRowData = unknown> {
	registerRowModel(rowModel: import('../store.js').RowModel<TRowData>): void;
	getRowModel(): import('../store.js').RowModel<TRowData> | null;
	triggerCellNotifications(rowId: string): void;
	batchedUpdates: boolean;
	registerCellSubscription(sub: CellSubscription): void;
	unregisterCellSubscription(sub: CellSubscription): void;
	updateCellSubscription(sub: CellSubscription, oldRowId: string, oldColField: string, newRowId: string, newColField: string): void;
	flushCellUpdatesSync(): void;
}

/**
 * Internal API intended for the rendering engine and custom framework adapters.
 * Plugin code should use GridPluginRuntime instead of sharing this broader surface.
 *
 * Access this from internal composition roots such as store-owned renderer/host wiring.
 */
export interface InternalGridApi<TRowData = unknown> extends GridRendererApi<TRowData>, GridHostRuntime<TRowData>, GridStoreRuntime<TRowData> {
	// ── Renderer-level display value access ──────────────────────────────────
	getCachedDisplayValue(rowId: string, colField: string): string | undefined;
	getCheapDisplayValue(rowId: string, colField: string): string;
	getComputedCellValue(rowId: string, colField: string): unknown;
	getCellState(rowId: string, colField: string): CellState;
	getCellAccess(rowId: string, colField: string): GridCellAccess<TRowData> | null;

	// ── Render config (viewport / overscan) ──────────────────────────────────
	getRowOverscanPx(): number;
	setRowOverscanPx(px: number): void;

	// ── Render diagnostics ───────────────────────────────────────────────────
	getRenderStats(): RenderStats;
	resetRenderStats(): void;

	// ── Visual row model access (used by renderer, not application code) ─────
	getVisualRow(index: number): VisualRow<TRowData> | null;
	getVisualRowCount(): number;
	getVisualIndexById(visualRowId: string): number | null;
	getVisualIndexByRowId(rowId: string): number | null;

	// ── Fine-grained subscriptions (used by cell/row portals) ────────────────
	subscribeToViewport(listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToSelection(listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToFocusedCell(listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToEditingCell(listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToCell(rowId: string, colField: string, listener: () => void): () => void;
	subscribeToRow(rowId: string, listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToColumn(colField: string, listener: GridSnapshotListener<TRowData>): () => void;
	subscribeToHeaders(listener: GridSnapshotListener<TRowData>): () => void;

	// ── Store / engine internals ─────────────────────────────────────────────
	registerRowModel(rowModel: import('../store.js').RowModel<TRowData>): void;
	getRowModel(): import('../store.js').RowModel<TRowData> | null;
	setViewportPins(pins: { left?: number; right?: number; top?: number; bottom?: number }): void;
	setViewportSize(width: number, height: number): boolean;
	updateVisibleRanges(): boolean;
	triggerCellNotifications(rowId: string): void;
	batchedUpdates: boolean;
	registerCellSubscription(sub: CellSubscription): void;
	unregisterCellSubscription(sub: CellSubscription): void;
	updateCellSubscription(sub: CellSubscription, oldRowId: string, oldColField: string, newRowId: string, newColField: string): void;
	flushCellUpdatesSync(): void;
}
