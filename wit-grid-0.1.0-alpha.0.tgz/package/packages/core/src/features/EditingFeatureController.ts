import { GridEventName } from '../api/GridEvents.js';
import { getValueByPath } from '../columnDef.js';
import type { GridFeatureContext } from './GridFeatureContext.js';
import type { DataModel } from '../models/DataModel.js';
import type { RowModel } from '../rowModel.js';
import { canEditCell } from '../visualRow.js';

export interface EditingFeatureControllerDeps<TRowData = unknown> {
	ctx: GridFeatureContext<TRowData>;
	getRowModel: () => RowModel<TRowData> | null;
	data: DataModel<TRowData>;
	notifyCellChange: (rowId: string, colField: string) => void;
	clearValidationError?: (rowId: string, colField: string) => void;
	setValidationError?: (rowId: string, colField: string, error: string) => void;
	validateCellPostCommit?: (rowId: string, colField: string) => Promise<void>;
}

export class EditingFeatureController<TRowData = unknown> {
	private readonly ctx: GridFeatureContext<TRowData>;
	private readonly getRowModel: () => RowModel<TRowData> | null;
	private readonly data: DataModel<TRowData>;
	private readonly notifyCellChange: (rowId: string, colField: string) => void;
	private readonly clearValidationError?: (rowId: string, colField: string) => void;
	private readonly setValidationError?: (rowId: string, colField: string, error: string) => void;
	private readonly validateCellPostCommit?: (rowId: string, colField: string) => Promise<void>;

	constructor(deps: EditingFeatureControllerDeps<TRowData>) {
		this.ctx = deps.ctx;
		this.getRowModel = deps.getRowModel;
		this.data = deps.data;
		this.notifyCellChange = deps.notifyCellChange;
		this.clearValidationError = deps.clearValidationError;
		this.setValidationError = deps.setValidationError;
		this.validateCellPostCommit = deps.validateCellPostCommit;
	}

	private canEditCell(rowId: string, colField: string): boolean {
		const rowModel = this.getRowModel();
		const rowIndex = rowModel ? rowModel.getVisualIndexByRowId(rowId) : -1;
		const visualRow = rowIndex >= 0 && rowModel ? rowModel.getVisualRow(rowIndex) : null;
		return canEditCell(visualRow, this.ctx.columns.getColumnDef(colField));
	}

	public startEdit(rowId: string, colField: string): void {
		if (!this.canEditCell(rowId, colField)) return;
		this.ctx.applyChange({
			reason: 'editing:start',
			state: { activeEdit: { rowId, colField } },
			invalidations: [
				{ kind: 'cell', rowId, colId: colField, reason: 'edit started' },
				{ kind: 'overlay', reason: 'edit started' },
			],
			domains: ['editing'],
			events: [{ type: GridEventName.editStarted, payload: { rowId, colField } }],
		});
		this.notifyCellChange(rowId, colField);
	}

	public stopEdit(cancel = false): void {
		const activeEdit = this.ctx.getState().activeEdit;
		if (!activeEdit) return;

		const { rowId, colField } = activeEdit;
		this.ctx.applyChange({
			reason: 'editing:stop',
			state: { activeEdit: null },
			invalidations: [
				{ kind: 'cell', rowId, colId: colField, reason: 'edit stopped' },
				{ kind: 'overlay', reason: 'edit stopped' },
			],
			domains: ['editing'],
			events: [{ type: GridEventName.editStopped, payload: { rowId, colField, cancel } }],
		});
		this.notifyCellChange(rowId, colField);
	}

	public async commitEdit(rowId: string, colField: string, value: unknown): Promise<boolean> {
		const col = this.ctx.columns.getColumnDef(colField);
		const oldValue = this.data.getRawCellValue(rowId, colField);
		const node = this.getRowModel()?.getRowNodeById(rowId);
		const row = node?.data ?? ({} as TRowData);

		if (col?.valueValidator) {
			let error: string | null = null;
			try {
				error = await col.valueValidator({ value, oldValue, row, colField });
			} catch {
				error = 'Validation failed';
			}
			if (error) {
				const activeEdit = this.ctx.getState().activeEdit;
				if (activeEdit?.rowId === rowId && activeEdit?.colField === colField) {
					this.ctx.applyChange({
						reason: 'editing:validation',
						state: { activeEdit: { ...activeEdit, validationError: error } },
						invalidations: [
							{ kind: 'cell', rowId, colId: colField, reason: 'edit stopped' },
							{ kind: 'overlay', reason: 'edit stopped' },
						],
					});
					this.notifyCellChange(rowId, colField);
				}
				this.setValidationError?.(rowId, colField, error);
				return false;
			}
		}

		let committedValue = value;
		let bypassValueSetter = false;

		if (col?.valueSetter) {
			let didAbort = false;
			const abort = () => {
				didAbort = true;
			};
			let success = true;
			const draftRow = { ...(row as Record<string, unknown>) } as TRowData;
			try {
				success = await col.valueSetter({ value, oldValue, row: draftRow, colField, abort });
			} catch {
				success = false;
			}
			if (!success || didAbort) {
				return false;
			}
			committedValue = getValueByPath(draftRow, colField);
			bypassValueSetter = true;
		}

		const result = this.ctx.applyChange({
			reason: 'data:set-cell-value',
			state: { activeEdit: null },
			domainMutations: [
				{
					kind: 'cell-value',
					rowId,
					colField,
					value: committedValue,
					source: 'edit',
					bypassValueSetter,
				},
			],
			invalidations: [
				{ kind: 'cell', rowId, colId: colField, reason: 'edit stopped' },
				{ kind: 'overlay', reason: 'edit stopped' },
			],
			domains: ['editing'],
			events: [{ type: GridEventName.editStopped, payload: { rowId, colField, cancel: false } }],
		});

		if (result.status !== 'committed' && result.status !== 'noop') {
			return false;
		}

		this.notifyCellChange(rowId, colField);
		if (this.validateCellPostCommit) {
			await this.validateCellPostCommit(rowId, colField);
		} else {
			this.clearValidationError?.(rowId, colField);
		}
		return true;
	}
}
