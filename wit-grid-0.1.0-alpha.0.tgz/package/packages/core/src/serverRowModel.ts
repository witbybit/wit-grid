import { type ColumnDef, setValueByPath } from './columnDef.js';
import { GridEventName } from './api/GridEvents.js';
import type { ServerRowModelRuntime } from './engine/runtimePorts.js';
import type { RowModel, RowRefreshReason, RowModelRefreshResult } from './rowModel.js';
import type { RowSelectionScope } from './api/GridApi.js';
import { RowNode } from './rowNode.js';
import { toDataVisualRowId, toLoadingVisualRowId } from './rows/visualRowIds.js';
import type { VisualRow } from './visualRow.js';

function toErrorMessage(error: unknown): string {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === 'string' && error.length > 0) return error;
	return 'Unknown server block load failure';
}

export interface GetRowsParams {
	startRow: number;
	endRow: number;
	sortModel: unknown;
	filterModel: unknown;
	/** 0-based page number; set when the grid is in page mode. */
	pageNumber?: number;
	/** Page size; set when the grid is in page mode. */
	pageSize?: number;
}

export interface IGridDatasource<TRowData = unknown> {
	getRows(params: GetRowsParams): Promise<{ rows: TRowData[]; totalCount?: number }>;
}

export interface ServerRowModelOptions<TData = unknown> {
	blockSize?: number;
	datasource: IGridDatasource<TData>;
	columns: Array<ColumnDef<TData>>;
	getRowId?: (row: TData) => string;
	/** When set, the model operates in page mode instead of infinite scroll. */
	pagination?: { pageSize: number; initialPage?: number };
}

export class ServerRowModelController<TData = unknown> implements RowModel<TData> {
	private readonly runtime: ServerRowModelRuntime<TData>;
	private datasource: IGridDatasource<TData>;
	private blockSize: number;
	private activeNodes: Array<RowNode<TData> | null> = [];
	private visualRows: Array<VisualRow<TData> | null> = [];
	private nodeMap = new Map<string, RowNode<TData>>();
	private visualRowIdToIndex = new Map<string, number>();
	private rowIdToVisualIndex = new Map<string, number>();
	private loadingBlocks: Record<number, boolean> = {};
	private loadingBlockCount = 0;
	private unsubscribers: Array<() => void> = [];
	private disposed = false;
	private requestGeneration = 0;

	// Pagination (null = infinite scroll mode)
	private readonly paginationPageSize: number | null;
	private currentPage = 0;
	private pageCount = 1;
	private totalRowsKnown = 0;

	constructor(runtime: ServerRowModelRuntime<TData>, options: ServerRowModelOptions<TData>) {
		this.runtime = runtime;
		this.datasource = options.datasource;
		this.blockSize = options.blockSize ?? 100;
		this.paginationPageSize = options.pagination?.pageSize ?? null;
		this.currentPage = options.pagination?.initialPage ?? 0;

		this.runtime.initializeModel({
			columns: options.columns,
			getRowId: options.getRowId,
		});

		this.runtime.registerRowModel(this);

		this.unsubscribers.push(
			this.runtime.addEventListener(GridEventName.sortChanged, () => this.purgeCache()),
			this.runtime.addEventListener(GridEventName.filterChanged, () => this.purgeCache())
		);

		// Trigger initial fetch of block 0 to obtain totalCount and sparse placeholders
		this.fetchBlock(0);
	}

	public setDatasource(datasource: IGridDatasource<TData>, blockSize: number = this.blockSize): void {
		this.datasource = datasource;
		this.blockSize = blockSize;
		this.purgeCache();
	}

	public goToPage(page: number): void {
		if (this.paginationPageSize === null) return;
		const clamped = Math.max(0, Math.min(page, this.pageCount - 1));
		if (clamped === this.currentPage) return;
		this.currentPage = clamped;
		this.purgeCache();
	}

	public dispose(): void {
		this.disposed = true;
		this.requestGeneration++;
		this.loadingBlocks = {};
		this.loadingBlockCount = 0;
		this.unsubscribers.forEach((unsubscribe) => unsubscribe());
		this.unsubscribers = [];
	}

	public getVisualRow = (rowIndex: number): VisualRow<TData> | null => {
		const row = this.visualRows[rowIndex];
		if (row) {
			return row;
		}
		if (rowIndex >= 0 && rowIndex < this.getVisualRowCount()) {
			return {
				kind: 'loading',
				id: toLoadingVisualRowId(rowIndex),
				rowIndex,
				editable: false,
			};
		}
		return null;
	};

	public loadVisibleBlocks = (startRow: number, endRow: number): void => {
		if (startRow > endRow) return;

		// If the user is flicking or dragging the scrollbar extremely fast, skip loading intermediate blocks.
		// When the scrolling stops, the scroll-stop pipeline resets velocity to 0 and triggers the resting block load.
		if (this.runtime.isScrollingFast()) {
			return;
		}

		const minRow = Math.max(0, startRow);
		const maxRow = Math.min(Math.max(0, endRow), Math.max(0, this.getVisualRowCount() - 1));
		if (minRow > maxRow) return;

		const visibleBlocks = new Set<number>();
		const minBlock = Math.floor(minRow / this.blockSize);
		const maxBlock = Math.floor(maxRow / this.blockSize);
		for (let blockIdx = minBlock; blockIdx <= maxBlock; blockIdx++) {
			visibleBlocks.add(blockIdx);
		}

		// Dynamic predictive pre-fetching based on scrolling velocity
		const velocity = this.runtime.getScrollVelocity();
		const vy = velocity.vy; // px/ms
		const totalBlocks = Math.ceil(this.getVisualRowCount() / this.blockSize);

		if (vy > 0.1) {
			// Scrolling down: proactively pre-fetch next 1 or 2 blocks
			const ahead1 = maxBlock + 1;
			const ahead2 = maxBlock + 2;
			if (ahead1 < totalBlocks) visibleBlocks.add(ahead1);
			if (ahead2 < totalBlocks) visibleBlocks.add(ahead2);
		} else if (vy < -0.1) {
			// Scrolling up: proactively pre-fetch previous 1 or 2 blocks
			const ahead1 = minBlock - 1;
			const ahead2 = minBlock - 2;
			if (ahead1 >= 0) visibleBlocks.add(ahead1);
			if (ahead2 >= 0) visibleBlocks.add(ahead2);
		}

		visibleBlocks.forEach((blockIdx) => {
			const startRow = blockIdx * this.blockSize;
			const isAlreadyLoaded = this.activeNodes[startRow] !== undefined && this.activeNodes[startRow] !== null;

			if (!isAlreadyLoaded && !this.loadingBlocks[blockIdx]) {
				this.fetchBlock(blockIdx);
			}
		});
	};

	public getRowNodeById = (rowId: string): RowNode<TData> | null => {
		return this.nodeMap.get(rowId) ?? null;
	};

	public getVisualRowCount = (): number => {
		return this.visualRows.length;
	};

	public getDataRowCount = (): number => {
		return this.visualRows.length;
	};

	public getVisualIndexById = (visualRowId: string): number => {
		const idx = this.visualRowIdToIndex.get(visualRowId);
		return idx !== undefined ? idx : -1;
	};

	public getVisualIndexByRowId = (rowId: string): number => {
		const idx = this.rowIdToVisualIndex.get(rowId);
		return idx !== undefined ? idx : -1;
	};

	public getRawRowById = (rowId: string): TData | null => {
		return this.nodeMap.get(rowId)?.data ?? null;
	};

	public getSelectableDataRowIds = (_scope: RowSelectionScope = 'loaded'): string[] => {
		const ids: string[] = [];
		for (const node of this.activeNodes) {
			if (node) ids.push(node.id);
		}
		return ids;
	};

	public setCellValue = (rowId: string, colField: string, value: unknown): boolean => {
		const node = this.getRowNodeById(rowId);
		if (!node) return false;

		const col = this.runtime.getColumnDef(colField);
		const oldValue = this.runtime.getCellValue(rowId, colField);
		const updatedRow = { ...node.data };
		if (col?.valueSetter) {
			const result = col.valueSetter({ value, oldValue, row: updatedRow, colField, abort: () => {} });
			if (!(result instanceof Promise) && !result) return false;
		} else {
			setValueByPath(updatedRow, colField, value);
		}

		node.setData(updatedRow);

		// If the edited cell field is currently part of active sort or filter models,
		// we must purge the cache and refetch from server to restore correct order/filters.
		const state = this.runtime.getState();
		let needsPurge = false;
		if (state.sortModel && state.sortModel.some((s) => s.colId === colField)) {
			needsPurge = true;
		} else if (state.filterModel && state.filterModel[colField] !== undefined) {
			needsPurge = true;
		}

		if (needsPurge) {
			this.purgeCache();
		}

		return true;
	};

	private fetchBlock = async (blockIndex: number): Promise<void> => {
		if (this.disposed) return;
		// Prevent duplicate calls
		if (this.loadingBlocks[blockIndex]) return;

		this.loadingBlocks[blockIndex] = true;
		this.loadingBlockCount++;
		const generation = this.requestGeneration;
		const requestStartedAt = typeof performance !== 'undefined' ? performance.now() : Date.now();

		// Set initial mount loading state and schedule immediate repaint only if fetching block 0
		if (blockIndex === 0) {
			this.runtime.setLoadingState(true);
		}

		// In page mode: translate block-local index to absolute datasource rows.
		// In infinite scroll mode: block index maps directly to global rows.
		const pageOffset = this.paginationPageSize !== null ? this.currentPage * this.paginationPageSize : 0;
		const localStartRow = blockIndex * this.blockSize;
		const absoluteStartRow = pageOffset + localStartRow;
		const absoluteEndRow = absoluteStartRow + this.blockSize;

		const state = this.runtime.getState();
		const requestSortModel = state.sortModel;
		const requestFilterModel = state.filterModel;

		try {
			const response = await this.datasource.getRows({
				startRow: absoluteStartRow,
				endRow: absoluteEndRow,
				sortModel: requestSortModel,
				filterModel: requestFilterModel,
				...(this.paginationPageSize !== null ? { pageNumber: this.currentPage, pageSize: this.paginationPageSize } : undefined),
			});

			if (this.disposed || generation !== this.requestGeneration) {
				return;
			}

			delete this.loadingBlocks[blockIndex];

			// Use page-local index for array storage (infinite scroll: localStartRow === absoluteStartRow)
			const storeStartRow = localStartRow;

			// Grow sparsely without pushing one placeholder per missing row.
			if (this.activeNodes.length < storeStartRow) {
				this.activeNodes.length = storeStartRow;
			}
			if (this.visualRows.length < storeStartRow) {
				this.visualRows.length = storeStartRow;
			}

			// Patch loaded rows into the array and index map
			response.rows.forEach((row, idx) => {
				const localIdx = storeStartRow + idx;
				const typedRow = row as TData;
				if (typedRow) {
					const id = this.runtime.getRowId(typedRow);
					let node = this.nodeMap.get(id);
					if (node) {
						node.setData(typedRow);
					} else {
						node = new RowNode<TData>(id, typedRow);
					}

					this.activeNodes[localIdx] = node;
					this.visualRows[localIdx] = {
						kind: 'data',
						id: toDataVisualRowId(node.id),
						rowId: node.id,
						node,
						depth: 0,
					};
					this.nodeMap.set(id, node);
					this.visualRowIdToIndex.set(toDataVisualRowId(id), localIdx);
					this.rowIdToVisualIndex.set(id, localIdx);
				} else {
					this.activeNodes[localIdx] = null;
					this.visualRows[localIdx] = null;
				}
			});

			// Resize sparse array to reflect the known row count for this view.
			if (typeof response.totalCount === 'number') {
				if (this.paginationPageSize !== null) {
					// Page mode: totalCount is the global total; size array to current page window.
					this.totalRowsKnown = response.totalCount;
					const newPageCount = Math.max(1, Math.ceil(response.totalCount / this.paginationPageSize));
					const currentPageRows = Math.min(
						this.paginationPageSize,
						Math.max(0, response.totalCount - this.currentPage * this.paginationPageSize)
					);
					if (this.activeNodes.length < currentPageRows) {
						this.activeNodes.length = currentPageRows;
					}
					if (this.visualRows.length < currentPageRows) {
						this.visualRows.length = currentPageRows;
					}
					if (newPageCount !== this.pageCount) {
						this.pageCount = newPageCount;
					}
					this.runtime.dispatchPaginationChanged({
						page: this.currentPage,
						pageCount: this.pageCount,
						totalRows: this.totalRowsKnown,
						pageSize: this.paginationPageSize,
					});
				} else {
					// Infinite scroll mode: size array to global total count.
					if (this.activeNodes.length < response.totalCount) {
						this.activeNodes.length = response.totalCount;
					}
					if (this.visualRows.length < response.totalCount) {
						this.visualRows.length = response.totalCount;
					}
				}
			}

			this.runtime.clearFormulas();

			// Layout geometry will be updated by GridEngine using GeometryModel
			this.loadingBlockCount = Math.max(0, this.loadingBlockCount - 1);
			const hasActiveFetches = this.loadingBlockCount > 0;
			this.runtime.setLoadingState(hasActiveFetches);

			const requestFinishedAt = typeof performance !== 'undefined' ? performance.now() : Date.now();
			this.runtime.dispatchServerBlockLoaded({
				blockIndex,
				loadedBlockStart: absoluteStartRow,
				loadedBlockEnd: absoluteStartRow + response.rows.length - 1,
				totalRecords: response.totalCount ?? pageOffset + this.activeNodes.length,
				durationMs: requestFinishedAt - requestStartedAt,
			});
		} catch (error) {
			if (this.disposed || generation !== this.requestGeneration) {
				return;
			}
			this.runtime.dispatchServerBlockLoadFailed({
				blockIndex,
				startRow: absoluteStartRow,
				endRow: absoluteEndRow - 1,
				message: toErrorMessage(error),
			});
			this.runtime.reportBlockLoadFailure(blockIndex, error);
			delete this.loadingBlocks[blockIndex];
			this.loadingBlockCount = Math.max(0, this.loadingBlockCount - 1);
			const hasActiveFetches = this.loadingBlockCount > 0;
			this.runtime.setLoadingState(hasActiveFetches);
		}
	};

	public purgeCache = (): void => {
		if (this.disposed) return;
		this.requestGeneration++;
		this.loadingBlocks = {};
		this.loadingBlockCount = 0;
		this.activeNodes = [];
		this.visualRows = [];
		this.nodeMap.clear();
		this.visualRowIdToIndex.clear();
		this.rowIdToVisualIndex.clear();
		this.runtime.clearFormulas();
		this.runtime.setLoadingState(true);
		// In page mode reset row array to the last known page window size so the
		// render engine shows the correct number of loading placeholders immediately.
		if (this.paginationPageSize !== null && this.totalRowsKnown > 0) {
			const currentPageRows = Math.min(this.paginationPageSize, Math.max(0, this.totalRowsKnown - this.currentPage * this.paginationPageSize));
			this.activeNodes.length = currentPageRows;
			this.visualRows.length = currentPageRows;
		}
		this.fetchBlock(0);
	};

	public refresh(reason?: RowRefreshReason): RowModelRefreshResult {
		this.purgeCache();
		return { changed: true };
	}
}
