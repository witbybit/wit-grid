import { hasImperativeRendererCapability, mountGridHost, type GridAdapterHandle, type GridHostWithAdapter } from '@wit-grid/core/internal';

export { hasImperativeRendererCapability, mountGridHost };
export type { GridAdapterHandle, GridHostWithAdapter };
