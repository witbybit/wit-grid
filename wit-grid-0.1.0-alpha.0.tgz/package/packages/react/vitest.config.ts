import { defineConfig } from 'vitest/config';
import { resolve } from 'node:path';

export default defineConfig({
	resolve: {
		alias: {
			'@wit-grid/core/experimental': resolve(__dirname, '../core/src/experimental.ts'),
			'@wit-grid/core/internal': resolve(__dirname, '../core/src/internal.ts'),
			'@wit-grid/core': resolve(__dirname, '../core/src/index.ts'),
		},
	},
	test: {
		environment: 'jsdom',
	},
});
